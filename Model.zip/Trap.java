package Model;

public class Trap extends Card{

    public Trap(String name,String description,String type,int price,String category){
        super(name,description,type,price,category);
    }

}
